﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Linq;
using System.Windows.Controls;
using ClassLibrary2;

namespace PROG6212_POE_P1
{
    public partial class MainWindow : Window
    {
        private List<Module> modules = new List<Module>();
        private int numberOfWeeks;
        private DateTime startDate;

        public MainWindow()
        {
            InitializeComponent();
            InitializeModulesComboBox();
        }

        private void InitializeModulesComboBox()
        {
            ModuleComboBox.ItemsSource = modules;
            ModuleComboBox.DisplayMemberPath = "Name";
        }

        private void AddModuleButton_Click(object sender, RoutedEventArgs e)//code for button which stores module details
        {
            if (!string.IsNullOrEmpty(ModuleCodeTextBox.Text) &&
                !string.IsNullOrEmpty(ModuleNameTextBox.Text) &&
                int.TryParse(ModuleCreditsTextBox.Text, out int credits) &&
                int.TryParse(ModuleClassHoursTextBox.Text, out int classHours))
            {
                Module newModule = new Module
                {
                    Code = ModuleCodeTextBox.Text,
                    Name = ModuleNameTextBox.Text,
                    Credits = credits,
                    ClassHoursPerWeek = classHours
                };
                modules.Add(newModule);
                ModuleComboBox.ItemsSource = null;
                ModuleComboBox.ItemsSource = modules;
                ClearModuleFields();
            }
            else
            {
                MessageBox.Show("Please enter valid module information.");
            }
        }

        private void ModuleComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)//combo box which stores all modules
        {
            if (ModuleComboBox.SelectedItem is Module selectedModule)
            {
                SelectedModuleTextBox.Text = $"Code: {selectedModule.Code}\n" +
                                             $"Name: {selectedModule.Name}\n" +
                                             $"Credits: {selectedModule.Credits}\n" +
                                             $"Class Hours/Week: {selectedModule.ClassHoursPerWeek}\n";

               
                CalculateSelfStudyHours(selectedModule);
            }
        }

        private void CalculateSelfStudyHours(Module module)
        {
            if (numberOfWeeks > 0 && startDate != default(DateTime))
            {
                DateTime currentDate = DateTime.Now;
                int currentWeek = (int)Math.Ceiling(currentDate.Subtract(startDate).TotalDays / 7);
                int selfStudyHours = (module.Credits * 10) / numberOfWeeks - module.ClassHoursPerWeek;

                SelectedModuleTextBox.Text += $"Self-Study Hours/Week: {selfStudyHours}\n" +
                                              $"Number of Weeks: {numberOfWeeks}\n" +
                                              $"Start Date: {startDate.ToShortDateString()}\n" +
                                              $"Current Week: {currentWeek}\n";
            }
        }

        private void ClearModuleFields()
        {
            ModuleCodeTextBox.Clear();
            ModuleNameTextBox.Clear();
            ModuleCreditsTextBox.Clear();
            ModuleClassHoursTextBox.Clear();
        }

        private void SetSemesterParametersButton_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(WeeksTextBox.Text, out int weeks) && DatePicker.SelectedDate.HasValue)
            {
                numberOfWeeks = weeks;
                startDate = DatePicker.SelectedDate.Value;
            }
            else
            {
                MessageBox.Show("Please enter valid semester information.");
            }
        }
    }
}
